package com.example.cdstermproject;

// 스위프트에서도 object 식으로 사용하긴 하는데
/*
자바는 꼭 이렇게 분리해야함.
Utils 이나 object으로 묶어두면 편리하지만 그렇지 않아서 상당히 힘들다 ㅠ_ㅠ
물론 다른 방법이 있을거임
 */
public class DataSource {
    public static String UserName;
    public static String profileUrl;
}
